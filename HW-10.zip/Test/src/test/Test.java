
package test;
import java.util.ArrayList;

import java.util.Iterator;

/**
 *
 * @author Sahil chaudhari
 * @Course CPSC-24500-004
 * @Date 11/7/20
 * @Discription Create three small classes unrelated by
 * inheritance - classes Building, Car and Bicycle. Give each class some unique appropriate
 * attributes and behaviors that it does not have in common with other classes.
 * Rewrite your program and apply available Java GUI features.
 */
public class Test {

    public static void main(String[] args) {
        
        ArrayList objs = new ArrayList<>();
        objs.add(new Building("Main office"));
        objs.add(new Car("CH-34578"));
        objs.add(new Bicycle("Honda"));
        //print object dentify info on carbonfootprint
        for (Iterator iterator = objs.iterator();
                iterator.hasNext();)
        {
            CarbonFootPrint carbonFootPrint = (CarbonFootPrint) iterator.next();
            double ft = carbonFootPrint.getCarbonFootPrint();
            System.out.print(carbonFootPrint + " Foot Print is: " + ft);    
            
        }
        
    }
    
}
    interface CarbonFootPrint {
        //Method to get Carbon Foor Print
        double getCarbonFootPrint();
    }
    //Bicycle implements interface carbonfootprint
    class Bicycle implements CarbonFootPrint {
    private String make;
        
    //Constructor
        
    Bicycle(String make){
        this.make = make;   
    }
        //method to get carbon foot print of bicycle
        //implement method from interface
    @Override
    public double getCarbonFootPrint() {
        return 10;
    }
    //return string bicycle object
    @Override
    public String toString() {
        return " Bicycle make: " + make;
    }
    }
    //class building implements carbonfootprint
    class Building implements CarbonFootPrint {
    private String buildingName;
    
    //constructor
    
    Building(String buildingNumber) {
        this.buildingName = buildingNumber;
    }
    // method to get carbonfootprint of building
    @Override
    public double getCarbonFootPrint(){
        return 50;
    }
    //return string building object
    @Override
    public String toString(){
        return " Building name: " + buildingName;
    }
    }
    //class Car implements carbonfootprint
    class Car implements CarbonFootPrint {
    private String RegNumber;
    
    //Constructor
    
    Car(String regNumber){
        this.RegNumber = regNumber;
    }
    //method to get carbonfootprint of Car
    @Override
    public double getCarbonFootPrint() {
        return 100;
    }
    @Override
    public String toString() {
        return " Car RegNumber: " + RegNumber;
    }
    
    }
    
    